$Id: README.txt,v 1.1 2006/05/12 01:16:00 kasiedu Exp $
To run validator:
1.Copy all schema  and xml files to the current directory(where this file is).
2. Open a command window and cd to the current directory.
3. type validate.bat YOUR_INSTANCE_DOCUMENT
replace  YOUR_INSTANCE_DOCUMENT with the name of your xml instance document.
4. If there are any errors a file 'errors.log' will be created in the current
directory and it should contain all the errors.