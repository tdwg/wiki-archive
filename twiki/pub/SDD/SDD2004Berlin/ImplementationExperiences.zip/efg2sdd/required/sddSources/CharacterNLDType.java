/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.5.2</a>, using an XML
 * Schema.
 * $Id: CharacterNLDType.java,v 1.2 2004/05/09 16:25:25 kasiedu Exp $
 */

package project.sdd.sddCastorsrc;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * For NaturalLanguageDescriptions.
 * 
 * The sequence and cardinality 
 * of elements is undefined and 
 * Text elements may be freely interspersed.
 * 
 * @version $Revision: 1.2 $ $Date: 2004/05/09 16:25:25 $
 */
public class CharacterNLDType extends CharacterNLDRefType implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items
     */
    private java.util.ArrayList _items;
 

      //----------------/
     //- Constructors -/
    //----------------/

    public CharacterNLDType() {
        super();
        _items = new ArrayList();
    } //-- project.sdd.sddCastorsrc.CharacterNLDType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addCharacterNLDTypeItem
     * 
     * @param vCharacterNLDTypeItem
     */
    public void addCharacterNLDTypeItem(project.sdd.sddCastorsrc.CharacterNLDTypeItem vCharacterNLDTypeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vCharacterNLDTypeItem);
    } //-- void addCharacterNLDTypeItem(project.sdd.sddCastorsrc.CharacterNLDTypeItem) 

    /**
     * Method addCharacterNLDTypeItem
     * 
     * @param index
     * @param vCharacterNLDTypeItem
     */
    public void addCharacterNLDTypeItem(int index, project.sdd.sddCastorsrc.CharacterNLDTypeItem vCharacterNLDTypeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vCharacterNLDTypeItem);
    } //-- void addCharacterNLDTypeItem(int, project.sdd.sddCastorsrc.CharacterNLDTypeItem) 

    /**
     * Method clearCharacterNLDTypeItem
     */
    public void clearCharacterNLDTypeItem()
    {
        _items.clear();
    } //-- void clearCharacterNLDTypeItem() 

    /**
     * Method enumerateCharacterNLDTypeItem
     */
    public java.util.Enumeration enumerateCharacterNLDTypeItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateCharacterNLDTypeItem() 

    /**
     * Method getCharacterNLDTypeItem
     * 
     * @param index
     */
    public project.sdd.sddCastorsrc.CharacterNLDTypeItem getCharacterNLDTypeItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (project.sdd.sddCastorsrc.CharacterNLDTypeItem) _items.get(index);
    } //-- project.sdd.sddCastorsrc.CharacterNLDTypeItem getCharacterNLDTypeItem(int) 

    /**
     * Method getCharacterNLDTypeItem
     */
    public project.sdd.sddCastorsrc.CharacterNLDTypeItem[] getCharacterNLDTypeItem()
    {
        int size = _items.size();
        project.sdd.sddCastorsrc.CharacterNLDTypeItem[] mArray = new project.sdd.sddCastorsrc.CharacterNLDTypeItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (project.sdd.sddCastorsrc.CharacterNLDTypeItem) _items.get(index);
        }
        return mArray;
    } //-- project.sdd.sddCastorsrc.CharacterNLDTypeItem[] getCharacterNLDTypeItem() 

    /**
     * Method getCharacterNLDTypeItemCount
     */
    public int getCharacterNLDTypeItemCount()
    {
        return _items.size();
    } //-- int getCharacterNLDTypeItemCount() 
 
  
    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeCharacterNLDTypeItem
     * 
     * @param vCharacterNLDTypeItem
     */
    public boolean removeCharacterNLDTypeItem(project.sdd.sddCastorsrc.CharacterNLDTypeItem vCharacterNLDTypeItem)
    {
        boolean removed = _items.remove(vCharacterNLDTypeItem);
        return removed;
    } //-- boolean removeCharacterNLDTypeItem(project.sdd.sddCastorsrc.CharacterNLDTypeItem) 

    /**
     * Method setCharacterNLDTypeItem
     * 
     * @param index
     * @param vCharacterNLDTypeItem
     */
    public void setCharacterNLDTypeItem(int index, project.sdd.sddCastorsrc.CharacterNLDTypeItem vCharacterNLDTypeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vCharacterNLDTypeItem);
    } //-- void setCharacterNLDTypeItem(int, project.sdd.sddCastorsrc.CharacterNLDTypeItem) 

    /**
     * Method setCharacterNLDTypeItem
     * 
     * @param characterNLDTypeItemArray
     */
    public void setCharacterNLDTypeItem(project.sdd.sddCastorsrc.CharacterNLDTypeItem[] characterNLDTypeItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < characterNLDTypeItemArray.length; i++) {
            _items.add(characterNLDTypeItemArray[i]);
        }
    } //-- void setCharacterNLDTypeItem(project.sdd.sddCastorsrc.CharacterNLDTypeItem) 

    /**
     * Method unmarshalCharacterNLDType
     * 
     * @param reader
     */
    public static java.lang.Object unmarshalCharacterNLDType(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (project.sdd.sddCastorsrc.CharacterNLDType) Unmarshaller.unmarshal(project.sdd.sddCastorsrc.CharacterNLDType.class, reader);
    } //-- java.lang.Object unmarshalCharacterNLDType(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
