/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.5.2</a>, using an XML
 * Schema.
 * $Id: ClassHierarchyNodeTypeChoiceDescriptor.java,v 1.4 2004/05/09 16:25:25 kasiedu Exp $
 */

package project.sdd.sddCastorsrc;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.mapping.AccessMode;
import org.exolab.castor.xml.TypeValidator;
import org.exolab.castor.xml.XMLFieldDescriptor;
import org.exolab.castor.xml.validators.*;

/**
 * Class ClassHierarchyNodeTypeChoiceDescriptor.
 * 
 * @version $Revision: 1.4 $ $Date: 2004/05/09 16:25:25 $
 */
public class ClassHierarchyNodeTypeChoiceDescriptor extends org.exolab.castor.xml.util.XMLClassDescriptorImpl {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field nsPrefix
     */
    private java.lang.String nsPrefix;

    /**
     * Field nsURI
     */
    private java.lang.String nsURI;

    /**
     * Field xmlName
     */
    private java.lang.String xmlName;

    /**
     * Field identity
     */
    private org.exolab.castor.xml.XMLFieldDescriptor identity;


      //----------------/
     //- Constructors -/
    //----------------/

    public ClassHierarchyNodeTypeChoiceDescriptor() {
        super();
        nsURI = "http://www.tdwg.org/2003/SDD_091";
        
        //-- set grouping compositor
        setCompositorAsChoice();
        org.exolab.castor.xml.util.XMLFieldDescriptorImpl  desc           = null;
        org.exolab.castor.xml.XMLFieldHandler              handler        = null;
        org.exolab.castor.xml.FieldValidator               fieldValidator = null;
        //-- initialize attribute descriptors
        
        //-- initialize element descriptors
        
        //-- _classHierarchyNodeTypeChoiceSequence
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.ClassHierarchyNodeTypeChoiceSequence.class, "_classHierarchyNodeTypeChoiceSequence", "-error-if-this-is-used-", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ClassHierarchyNodeTypeChoice target = (ClassHierarchyNodeTypeChoice) object;
                return target.getClassHierarchyNodeTypeChoiceSequence();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ClassHierarchyNodeTypeChoice target = (ClassHierarchyNodeTypeChoice) object;
                    target.setClassHierarchyNodeTypeChoiceSequence( (project.sdd.sddCastorsrc.ClassHierarchyNodeTypeChoiceSequence) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.ClassHierarchyNodeTypeChoiceSequence();
            }
        } );
        desc.setHandler(handler);
        desc.setContainer(true);
        desc.setClassDescriptor(new project.sdd.sddCastorsrc.ClassHierarchyNodeTypeChoiceSequenceDescriptor());
	// CHANGED TO FALSE BY J. ASIEDU
        desc.setRequired(false);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _classHierarchyNodeTypeChoiceSequence
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(0);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _nodesCHNT
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.NodesCHNT.class, "_nodesCHNT", "Nodes", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ClassHierarchyNodeTypeChoice target = (ClassHierarchyNodeTypeChoice) object;
                return target.getNodesCHNT();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ClassHierarchyNodeTypeChoice target = (ClassHierarchyNodeTypeChoice) object;
                    target.setNodesCHNT( (project.sdd.sddCastorsrc.NodesCHNT) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.NodesCHNT();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.tdwg.org/2003/SDD_091");
	// CHANGED TO FALSE BY J. ASIEDU
        desc.setRequired(false);        
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _nodesCHNT
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(0);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
    } //-- project.sdd.sddCastorsrc.ClassHierarchyNodeTypeChoiceDescriptor()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method getAccessMode
     */
    public org.exolab.castor.mapping.AccessMode getAccessMode()
    {
        return null;
    } //-- org.exolab.castor.mapping.AccessMode getAccessMode() 

    /**
     * Method getExtends
     */
    public org.exolab.castor.mapping.ClassDescriptor getExtends()
    {
        return null;
    } //-- org.exolab.castor.mapping.ClassDescriptor getExtends() 

    /**
     * Method getIdentity
     */
    public org.exolab.castor.mapping.FieldDescriptor getIdentity()
    {
        return identity;
    } //-- org.exolab.castor.mapping.FieldDescriptor getIdentity() 

    /**
     * Method getJavaClass
     */
    public java.lang.Class getJavaClass()
    {
        return project.sdd.sddCastorsrc.ClassHierarchyNodeTypeChoice.class;
    } //-- java.lang.Class getJavaClass() 

    /**
     * Method getNameSpacePrefix
     */
    public java.lang.String getNameSpacePrefix()
    {
        return nsPrefix;
    } //-- java.lang.String getNameSpacePrefix() 

    /**
     * Method getNameSpaceURI
     */
    public java.lang.String getNameSpaceURI()
    {
        return nsURI;
    } //-- java.lang.String getNameSpaceURI() 

    /**
     * Method getValidator
     */
    public org.exolab.castor.xml.TypeValidator getValidator()
    {
        return this;
    } //-- org.exolab.castor.xml.TypeValidator getValidator() 

    /**
     * Method getXMLName
     */
    public java.lang.String getXMLName()
    {
        return xmlName;
    } //-- java.lang.String getXMLName() 

}
