/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.5.2</a>, using an XML
 * Schema.
 * $Id: ConceptTreeNodeTypeDescriptor.java,v 1.4 2004/05/09 16:25:25 kasiedu Exp $
 */

package project.sdd.sddCastorsrc;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.mapping.AccessMode;
import org.exolab.castor.xml.TypeValidator;
import org.exolab.castor.xml.XMLFieldDescriptor;
import org.exolab.castor.xml.validators.*;

/**
 * Class ConceptTreeNodeTypeDescriptor.
 * 
 * @version $Revision: 1.4 $ $Date: 2004/05/09 16:25:25 $
 */
public class ConceptTreeNodeTypeDescriptor extends org.exolab.castor.xml.util.XMLClassDescriptorImpl {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field nsPrefix
     */
    private java.lang.String nsPrefix;

    /**
     * Field nsURI
     */
    private java.lang.String nsURI;

    /**
     * Field xmlName
     */
    private java.lang.String xmlName;

    /**
     * Field identity
     */
    private org.exolab.castor.xml.XMLFieldDescriptor identity;


      //----------------/
     //- Constructors -/
    //----------------/

    public ConceptTreeNodeTypeDescriptor() {
        super();
        nsURI = "http://www.tdwg.org/2003/SDD_091";
        xmlName = "ConceptTreeNodeType";
        
        //-- set grouping compositor
        setCompositorAsSequence();
        org.exolab.castor.xml.util.XMLFieldDescriptorImpl  desc           = null;
        org.exolab.castor.xml.XMLFieldHandler              handler        = null;
        org.exolab.castor.xml.FieldValidator               fieldValidator = null;
        //-- initialize attribute descriptors
        
        //-- _key
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.Integer.TYPE, "_key", "key", org.exolab.castor.xml.NodeType.Attribute);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                if(!target.hasKey())
                    return null;
                return new Integer(target.getKey());
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    // ignore null values for non optional primitives
                    if (value == null) return;
                    
                    target.setKey( ((Integer)value).intValue());
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setRequired(true);
        addFieldDescriptor(desc);
        
        //-- validation code for: _key
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
            IntegerValidator typeValidator = new IntegerValidator();
            typeValidator.setMinInclusive(0);
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- _debugkey
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.String.class, "_debugkey", "debugkey", org.exolab.castor.xml.NodeType.Attribute);
        desc.setImmutable(true);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getDebugkey();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setDebugkey( (java.lang.String) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        addFieldDescriptor(desc);
        
        //-- validation code for: _debugkey
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
            StringValidator typeValidator = new StringValidator();
            typeValidator.setWhiteSpace("preserve");
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- initialize element descriptors
        
        //-- _label
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.LabelPlusWording3Type.class, "_label", "Label", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getLabel();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setLabel( (project.sdd.sddCastorsrc.LabelPlusWording3Type) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.LabelPlusWording3Type();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.tdwg.org/2003/SDD_091");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _label
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _richAnnotationGroup
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.RichAnnotationGroup.class, "_richAnnotationGroup", "-error-if-this-is-used-", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getRichAnnotationGroup();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setRichAnnotationGroup( (project.sdd.sddCastorsrc.RichAnnotationGroup) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.RichAnnotationGroup();
            }
        } );
        desc.setHandler(handler);
        desc.setContainer(true);
        desc.setClassDescriptor(new project.sdd.sddCastorsrc.RichAnnotationGroupDescriptor());
        desc.setRequired(false);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _richAnnotationGroup
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _dependencyRules
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.DependencyRules.class, "_dependencyRules", "DependencyRules", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getDependencyRules();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setDependencyRules( (project.sdd.sddCastorsrc.DependencyRules) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.DependencyRules();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.tdwg.org/2003/SDD_091");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _dependencyRules
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _conceptStates
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.ConceptStates.class, "_conceptStates", "ConceptStates", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getConceptStates();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setConceptStates( (project.sdd.sddCastorsrc.ConceptStates) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.ConceptStates();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.tdwg.org/2003/SDD_091");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _conceptStates
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _statisticalMeasureSet
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.StatisticalMeasureSet.class, "_statisticalMeasureSet", "StatisticalMeasureSet", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getStatisticalMeasureSet();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setStatisticalMeasureSet( (project.sdd.sddCastorsrc.StatisticalMeasureSet) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.StatisticalMeasureSet();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.tdwg.org/2003/SDD_091");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _statisticalMeasureSet
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- __ApplicableModifiers
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.__ApplicableModifiers.class, "__ApplicableModifiers", "__ApplicableModifiers", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.get_ApplicableModifiers();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.set_ApplicableModifiers( (project.sdd.sddCastorsrc.__ApplicableModifiers) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.__ApplicableModifiers();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.tdwg.org/2003/SDD_091");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: __ApplicableModifiers
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _autoAddToCharacters
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.AutoAddToCharacters.class, "_autoAddToCharacters", "AutoAddToCharacters", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getAutoAddToCharacters();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setAutoAddToCharacters( (project.sdd.sddCastorsrc.AutoAddToCharacters) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.AutoAddToCharacters();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.tdwg.org/2003/SDD_091");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _autoAddToCharacters
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _conceptTreeNodeTypeChoice
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(project.sdd.sddCastorsrc.ConceptTreeNodeTypeChoice.class, "_conceptTreeNodeTypeChoice", "-error-if-this-is-used-", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                return target.getConceptTreeNodeTypeChoice();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    ConceptTreeNodeType target = (ConceptTreeNodeType) object;
                    target.setConceptTreeNodeTypeChoice( (project.sdd.sddCastorsrc.ConceptTreeNodeTypeChoice) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new project.sdd.sddCastorsrc.ConceptTreeNodeTypeChoice();
            }
        } );
        desc.setHandler(handler);
        desc.setContainer(true);
        desc.setClassDescriptor(new project.sdd.sddCastorsrc.ConceptTreeNodeTypeChoiceDescriptor());
        desc.setRequired(false);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _conceptTreeNodeTypeChoice
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
    } //-- project.sdd.sddCastorsrc.ConceptTreeNodeTypeDescriptor()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method getAccessMode
     */
    public org.exolab.castor.mapping.AccessMode getAccessMode()
    {
        return null;
    } //-- org.exolab.castor.mapping.AccessMode getAccessMode() 

    /**
     * Method getExtends
     */
    public org.exolab.castor.mapping.ClassDescriptor getExtends()
    {
        return null;
    } //-- org.exolab.castor.mapping.ClassDescriptor getExtends() 

    /**
     * Method getIdentity
     */
    public org.exolab.castor.mapping.FieldDescriptor getIdentity()
    {
        return identity;
    } //-- org.exolab.castor.mapping.FieldDescriptor getIdentity() 

    /**
     * Method getJavaClass
     */
    public java.lang.Class getJavaClass()
    {
        return project.sdd.sddCastorsrc.ConceptTreeNodeType.class;
    } //-- java.lang.Class getJavaClass() 

    /**
     * Method getNameSpacePrefix
     */
    public java.lang.String getNameSpacePrefix()
    {
        return nsPrefix;
    } //-- java.lang.String getNameSpacePrefix() 

    /**
     * Method getNameSpaceURI
     */
    public java.lang.String getNameSpaceURI()
    {
        return nsURI;
    } //-- java.lang.String getNameSpaceURI() 

    /**
     * Method getValidator
     */
    public org.exolab.castor.xml.TypeValidator getValidator()
    {
        return this;
    } //-- org.exolab.castor.xml.TypeValidator getValidator() 

    /**
     * Method getXMLName
     */
    public java.lang.String getXMLName()
    {
        return xmlName;
    } //-- java.lang.String getXMLName() 

}
