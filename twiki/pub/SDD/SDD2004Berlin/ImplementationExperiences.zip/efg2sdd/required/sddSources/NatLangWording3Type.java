/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.5.2</a>, using an XML
 * Schema.
 * $Id: NatLangWording3Type.java,v 1.3 2004/05/09 16:25:25 kasiedu Exp $
 */

package project.sdd.sddCastorsrc;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Natural language wording for elements with repeated content like
 * characters that contain multiple modifiers + states. (= 'Array-'
 * or 'ContainerWording')
 * 
 * @version $Revision: 1.3 $ $Date: 2004/05/09 16:25:25 $
 */
public class NatLangWording3Type extends project.sdd.sddCastorsrc.NatLangWording2Type 
implements java.io.Serializable
{
    //ADDED FIELD BY J. ASIEDU
 /**
     * Field _delimiterGroup
     */
    private project.sdd.sddCastorsrc.DelimiterGroup _delimiterGroup;
    //END ADDED FIELD BY J. ASIEDU
      //----------------/
     //- Constructors -/
    //----------------/

    public NatLangWording3Type() {
        super();
    } //-- project.sdd.sddCastorsrc.NatLangWording3Type()


      //-----------/
     //- Methods -/
    //-----------/

    //ADDED METHOD BY J.ASIEDU
    /**
     * Returns the value of field 'delimiterGroup'.
     * 
     * @return the value of field 'delimiterGroup'.
     */
    public project.sdd.sddCastorsrc.DelimiterGroup getDelimiterGroup()
    {
        return this._delimiterGroup;
    } //-- project.sdd.sddCastorsrc.DelimiterGroup getDelimiterGroup() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method unmarshalNatLangWording3Type
     * 
     * @param reader
     */
    public static java.lang.Object unmarshalNatLangWording3Type(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (project.sdd.sddCastorsrc.NatLangWording3Type) Unmarshaller.unmarshal(project.sdd.sddCastorsrc.NatLangWording3Type.class, reader);
    } //-- java.lang.Object unmarshalNatLangWording3Type(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

    //ADDED SETTER BY J. ASIEDU
  /**
     * Sets the value of field 'delimiterGroup'.
     * 
     * @param delimiterGroup the value of field 'delimiterGroup'.
     */
    public void setDelimiterGroup(project.sdd.sddCastorsrc.DelimiterGroup delimiterGroup)
    {
        this._delimiterGroup = delimiterGroup;
    } //-- void setDelimiterGroup(project.sdd.sddCastorsrc.DelimiterGroup) 

}
