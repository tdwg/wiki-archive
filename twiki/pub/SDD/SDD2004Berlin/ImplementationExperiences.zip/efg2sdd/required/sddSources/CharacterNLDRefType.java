/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.5.2</a>, using an XML
 * Schema.
 * $Id: CharacterNLDRefType.java,v 1.2 2004/05/09 16:25:25 kasiedu Exp $
 */

package project.sdd.sddCastorsrc;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Refers to a character (e.�g. from within concept trees or from
 * Descriptions). It consists only of a reference to a Character
 * definition key.
 * 
 * @version $Revision: 1.2 $ $Date: 2004/05/09 16:25:25 $
 */
public class CharacterNLDRefType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * ref refers to a character definition key
     * (Terminology/Characters/Character)
     */
    private int _ref;

    /**
     * keeps track of state for field: _ref
     */
    private boolean _has_ref;

    /**
     * An optional attribute to add a human-readable equivalent to
     * the numeric ref to simplify debugging SDD applications. The
     * attribute can be discarded or updated at any time.
     * Applications should not produce exports containing this
     * attribute, instead it can be generated using xslt (based on
     * labels/abbreviations reached through key/ref).
     */
    private java.lang.String _debugref;


      //----------------/
     //- Constructors -/
    //----------------/

    public CharacterNLDRefType() {
        super();
    } //-- project.sdd.sddCastorsrc.CharacterNLDRefType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'debugref'. The field 'debugref'
     * has the following description: An optional attribute to add
     * a human-readable equivalent to the numeric ref to simplify
     * debugging SDD applications. The attribute can be discarded
     * or updated at any time. Applications should not produce
     * exports containing this attribute, instead it can be
     * generated using xslt (based on labels/abbreviations reached
     * through key/ref).
     * 
     * @return the value of field 'debugref'.
     */
    public java.lang.String getDebugref()
    {
        return this._debugref;
    } //-- java.lang.String getDebugref() 

    /**
     * Returns the value of field 'ref'. The field 'ref' has the
     * following description: ref refers to a character definition
     * key (Terminology/Characters/Character)
     * 
     * @return the value of field 'ref'.
     */
    public int getRef()
    {
        return this._ref;
    } //-- int getRef() 

    /**
     * Method hasRef
     */
    public boolean hasRef()
    {
        return this._has_ref;
    } //-- boolean hasRef() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'debugref'. The field 'debugref' has
     * the following description: An optional attribute to add a
     * human-readable equivalent to the numeric ref to simplify
     * debugging SDD applications. The attribute can be discarded
     * or updated at any time. Applications should not produce
     * exports containing this attribute, instead it can be
     * generated using xslt (based on labels/abbreviations reached
     * through key/ref).
     * 
     * @param debugref the value of field 'debugref'.
     */
    public void setDebugref(java.lang.String debugref)
    {
        this._debugref = debugref;
    } //-- void setDebugref(java.lang.String) 

    /**
     * Sets the value of field 'ref'. The field 'ref' has the
     * following description: ref refers to a character definition
     * key (Terminology/Characters/Character)
     * 
     * @param ref the value of field 'ref'.
     */
    public void setRef(int ref)
    {
        this._ref = ref;
        this._has_ref = true;
    } //-- void setRef(int) 

    /**
     * Method unmarshalCharacterNLDRefType
     * 
     * @param reader
     */
    public static java.lang.Object unmarshalCharacterNLDRefType(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (project.sdd.sddCastorsrc.CharacterNLDRefType) Unmarshaller.unmarshal(project.sdd.sddCastorsrc.CharacterNLDRefType.class, reader);
    } //-- java.lang.Object unmarshalCharacterNLDRefType(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
