(Compare notes made in attempt 1)

Here the include was removed from SDD and the UBIF_Lib content directly pasted into SDD.xsd at the end.
The goal was to remove a possible namespace ambiguity, which may be a bug in xmlspy.

Both SDD_min1 and 2 now validate, also SDD_tech.xml - under some circumstances. I first thought that it did not, 
and this may well be the case for you:

Close spy, then start xmlspy 2004, rel. 4 new on SDD.xsd, it validates ok in schema view, and in text view.

However, if I first start with UBIF.xsd (which validates ok), leave that in text view, and now open SDD.xsd,
it validates SDD in schema view, but when switching to text view reports an error "undefined value for member types encountered
inside the UBIF_Lib.xsd. The reported member types of a union in UBIF_Lib.xsd are present in UBIF_Lib.xsd. 

This buggy behaviour may be helpful to understand what happens when validating the instance documents, when 
other schemata have been opened previously.

Gregor

