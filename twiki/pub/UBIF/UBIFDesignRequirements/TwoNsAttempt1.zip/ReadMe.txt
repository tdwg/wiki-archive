Here both UBIF and SDD include the chamelon library (no targetnamespace) UBIF_Lib.xsd.

Both UBIF and SDD are valid in schema validation (graphic and text view); the example file SDD_min1.xml is also valid.

The file SDD_min2.xml is, however, invalid in XMLSPY, 2004 rel. 4.
It differs from SDD_min1.xml by having a CustomExtension both in the UBIF and in the SDD part.
The UBIF-part validates ok, but the SDD part says:

"mandatory element belongs to namespace UBIF, but you have not defined a prefix for that namespace."

(and after adding a ub namespace, as in SDD_tech.xml:)

"mandatory element ub:CustomExtension expected in place of CustomExtension".

The CustomExtensions are defined in UBIF_Lib.xsd and are included both by UBIF.xsd and SDD.xsd.
According to the chameleon pattern, they should acquire the namespace of the importing library. It seems, however,
that they do not so in XMLSPY, which seems to ignore the SDD.CustomExtensions and assume (even though there is 
no namespace prefix and though the default namespace in DescriptiveData is xmlns="http://www.tdwg.org/2004/SDD") that
CustomExtensions must be UBIF.CustomExtensions.

---

General note: Spy 2004.4 has a confirmed bug, that instance documents never validate when the schema is open in schema view
in another window, and key/ref (identity constraints) are used in the schema). Thus, either do not keep the schema open when 
validating instance documents, or be sure the schema is switched to text mode.

---

Note that all schemata use elementFormDefault="qualified" attributeFormDefault="unqualified". The aim is not to remove
a namespace prefix inside SDD, but to make sure that everything inside DescriptiveData in instance documents is in the SDD namespace.
This may be defined as  xmlns:sdd="http://www.tdwg.org/2004/SDD", i.e. everything would be prefixed with "sdd".

---

I had a similar problem with the use of global attributes defined in UBIF_Lib.xsd, but in that
case I found a work-around by putting the attributes into attribute groups, which are derefenced ok. 
The CustomExtensions is inherited by means of a element group, which is defined in UBIF_Lib.xsd.

I see no way around this problem at the moment other than that attempted Attempt2, to include the library file using copy and paste (and
have the associated update problems).

Gregor
