<?php
	header('Content-Type: image/jpg');
	readfile('monty_and_meg.jpg');	
?>
