<?php

	// Whatever happens we are going to output XML
	// so set the header appropriately
	header('Content-Type: text/xml');

	// check if they are submitting an LSID	
	if (isset($_GET['lsid']) && $_GET['lsid'])
	{
		// an lsid has been passed so they are calling
		// the getAvailableServices(lsid) method and we
		// should return the appropriate WSDL.				
		$tempValues['{DATA_ADDRESS}'] = "http://". $_SERVER['SERVER_NAME'] ."/authority/data.php";
		$tempValues['{METADATA_ADDRESS}'] = "http://". $_SERVER['SERVER_NAME'] ."/authority/metadata.php";
		echo fillTemplate('DataServices.wsdl', $tempValues);
	}
	else
	{
		// no lsid has been passed so they are asking
		// how they should call the getAvailableServices(lsid) method.
		// we should return an WSDL with the right location in it.		
		$tempValues['AUTHORITY_ADDRESS'] = "http://". $_SERVER['SERVER_NAME'] ."/";		
		echo fillTemplate('Authority.wsdl', $tempValues);

	}
	

	// opens a template file, subsitutes values and 
	// returns file contents as string
	function fillTemplate($template, $inValues){

		// these files are small so read the whole thing into memory.		
		if ($theFile = fopen($template, 'r')){			
			$templateString = fread($theFile, filesize($template));
			fclose($theFile);
		}
		
		// simple string replacements
		$theKeys = array_keys($inValues);
		foreach($theKeys as $theKey){
			$templateString = str_replace($theKey, $inValues[$theKey], $templateString);
		}
		
		return $templateString;	
	}

?>
