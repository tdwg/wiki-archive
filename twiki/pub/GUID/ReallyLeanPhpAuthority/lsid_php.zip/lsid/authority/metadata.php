<?php
	
	/*
	 This is a demo file to return some metadata in RDF.

	 It is like a simple script of generating HTML but it returns RDF.
	 
	 The lines below generate some data on the basis of the LSID string
	 to allow the user to click around. This code could be replaced
	 by some simple data access calls to generate real metadata.
	
	*/
	
	// some namespaces to mix it up a bit.
	$namespaces = array('apples', 'oranges', 'bananas', 'dharma', 'zen', 'coffee', 'tea', 'beer', 'wine', 'gin');
		
	$lsid = $_GET['lsid'];
	$lsidParts = explode(":", $lsid );	

	$parts = explode(":", $lsid );
	
	// Is Replaced By
	$parts[4] = $lsidParts[4] + 1;
	$parts[3] = $namespaces[$parts[4] % 10];
	$isReplacedBy = implode(":", $parts);
	
	// Replaces
	$parts[4] = $lsidParts[4] - 1;
	$parts[3] = $namespaces[$lsidParts[4] % 10];
	$replaces = implode(":", $parts);

	// Is Part Of
	$parts[4] = ($lsidParts[4] - ($lsidParts[4] % 10)) * 10;
	$parts[3] = $namespaces[$lsidParts[4] % 10];
	$isPartOf = implode(":", $parts);
	
	
	// tell them it is XML in the header.
	header('Content-Type: text/xml');	
	echo '<?xml version="1.0"?>';
	
?>
<rdf:RDF
	xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
	xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:dcterms="http://purl.org/dc/terms/"
	
>
	<rdf:Description rdf:about="<?php echo $lsid ?>">
		<dc:title>Metadata for object "<?php echo $lsidParts[4] ?>" in namespace "<?php echo $lsidParts[3] ?>" at authority "<?php echo $lsidParts[2] ?>"</dc:title>
		<dc:creator>Roger Hyam</dc:creator>
		<dc:description>
			This is some rubbish data that is made up pseudo randomly from the LSID string itself.
			It would be simple to replace the script that is generating this with one that runs an SQL
			query against a database and returns something sensible.
			The links from this LSID to others are random - they are just there to let you click around a bit.
			THERE IS NO ERROR HANDLING IN THIS DEMO!
		</dc:description>
		<dc:subject>A demo of a simple LSID authority.</dc:subject>
		<dc:date><?php echo date("Y-m-d") ?></dc:date>
		<rdfs:label>Object "<?php echo $lsidParts[4] ?>" in the "<?php echo $lsidParts[3] ?>" database.</rdfs:label>
		<dcterms:replaces rdf:resource="<?php echo $replaces ?>"/>
		<dcterms:isReplacedBy rdf:resource="<?php echo $isReplacedBy ?>"/>
		<dcterms:isPartOf rdf:resource="<?php echo $isPartOf ?>"/>
		<!-- <dc:format rdf:resource="urn:lsid:i3c.org:formats:jpg" /> -->
	</rdf:Description>
	
</rdf:RDF>
